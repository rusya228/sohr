﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(textBox1.Text);
            int b = Convert.ToInt32(textBox2.Text);
            int c = Convert.ToInt32(textBox3.Text);
            double D = (Math.Pow(b, 2) - (4 * a * c));
            listBox1.Items.Add("Дискриминант: " + D);
            if (D<0)
            {
                listBox1.Items.Add("Корней нет!");
            }
            if (D==0)
            {
                int K1=(b*(-1))/(2*a);
                listBox1.Items.Add($"1 корень: {K1}");
            }
            if (D > 0)
            {
                double K1 = (b*(-1) + (Math.Sqrt(D))) / (2 * a);
                double K2 =(b*(-1) - (Math.Sqrt(D))) / (2 * a);
                listBox1.Items.Add($"1 корень: {K1}");
                listBox1.Items.Add($"2 корень: {K2}");
            }
        }
    }
}
